from typing import TypedDict, List, Union, Optional
from dataclasses import dataclass

class FormData(TypedDict):
    industry: str
    years: int
    employees: int
    revenue_trend: int
    likability: int
    market_share: int
    customer_base: str
    usp: int
    digital_skills: int
    data_management: int
    profit_margins: int
    debt: int
    cash_flow: int
    digital_strategy: List[str]
    email: Optional[str]
    phone: Optional[str]

@dataclass
class StrategyResult:
    score: float
    recommendations: List[str]
    metis_link: str

def normalize_score(value: int, scale_max: int) -> float:
    """Normalize a value to a 0-10 scale."""
    return (value - 1) / (scale_max - 1) * 10

def get_industry_tools(industry_id: int) -> List[tuple[str, int]]:
    """Get the recommended tools for a specific industry."""
    industry_tools = {
        1: [  # Retail
            ('CRM', 8),
            ('E-commerce Platforms', 10),
            ('Accounting and Invoicing', 9),
            ('Marketing Automation Tools', 7),
            ('Cloud Storage and Collaboration', 6),
            ('Analytics and Reporting Tools', 8),
            ('Social Media Presence and SEO', 9),
            ('Mobile App (Loyalty/Purchases)', 7),
            ('Online Appointment Tools', 4),
        ],
        2: [  # Food and Beverages
            ('CRM', 7),
            ('Mobile Ordering App / Site', 8),
            ('QR Code Menus', 9),
            ('E-commerce Platforms', 9),
            ('Accounting and Invoicing', 8),
            ('Marketing Automation Tools', 6),
            ('Cloud Storage and Collaboration', 5),
            ('Social Media Presence and SEO', 9),
            ('Online Appointment Tools', 7),
            ('Project Management Tools', 4),
        ],
        3: [  # Services
            ('Mobile App for Bookings', 8),
            ('CRM', 8),
            ('Accounting and Invoicing', 7),
            ('Marketing Automation Tools', 6),
            ('Cloud Storage and Collaboration', 5),
            ('Social Media Presence and SEO', 8),
            ('Online Appointment Tools', 10),
            ('Project Management Tools', 3),
        ],
        4: [  # Tourism and Leisure
            ('CRM', 9),
            ('E-commerce Platforms', 9),
            ('Accounting and Invoicing', 7),
            ('Project Management Tools', 6),
            ('Marketing Automation Tools', 7),
            ('Cloud Storage and Collaboration', 6),
            ('Dynamic Pricing Tools', 7),
            ('Social Media Presence and SEO', 10),
            ('Online Appointment Tools', 8),
        ],
        5: [  # Education and Arts
            ('CRM', 7),
            ('Virtual Classrooms', 8),
            ('E-commerce Platforms', 8),
            ('Accounting and Invoicing', 7),
            ('Marketing Automation Tools', 6),
            ('Cloud Storage and Collaboration', 7),
            ('Social Media Presence and SEO', 8),
            ('Online Appointment Tools', 6),
            ('Project Management Tools', 5),
        ],
        6: [  # Technology
            ('CRM', 8),
            ('E-commerce Platforms', 6),
            ('Accounting and Invoicing', 9),
            ('Project Management Tools', 10),
            ('Marketing Automation Tools', 7),
            ('Cloud Storage and Collaboration', 9),
            ('Cybersecurity Solutions', 10),
            ('Communication Tools', 9),
            ('Analytics and Reporting Tools', 8),
            ('Social Media Presence and SEO', 7),
        ],
        7: [  # Construction and Maintenance
            ('CRM', 7),
            ('Accounting and Invoicing', 8),
            ('Marketing Automation Tools', 4),
            ('Cloud Storage and Collaboration', 6),
            ('Social Media Presence and SEO', 7),
            ('Online Appointment Tools', 8),
            ('Project Management Tools', 7),
        ],
        8: [  # Transportation
            ('CRM', 6),
            ('Ride-Hailing App Integration', 9),
            ('GPS Fleet Tracking', 8),
            ('Dynamic Route Optimization', 7),
            ('E-commerce Platforms', 9),
            ('Accounting and Invoicing', 7),
            ('Project Management Tools', 6),
            ('Marketing Automation Tools', 5),
            ('Cloud Storage and Collaboration', 5),
            ('Social Media Presence and SEO', 7),
            ('Online Appointment Tools', 8),
        ],
        9: [  # Health and Wellness
            ('CRM', 8),
            ('Accounting and Invoicing', 7),
            ('Marketing Automation Tools', 6),
            ('Cloud Storage and Collaboration', 6),
            ('Social Media Presence and SEO', 8),
            ('Online Appointment Tools', 10),
            ('Wearable Device Integration', 7),
            ('Electronic Health Records (integrations)', 8),
            ('Project Management Tools', 4),
        ],
        10: [  # Manufacturing & Craftsmanship
            ('CRM', 6),
            ('E-commerce Platforms', 9),
            ('Accounting and Invoicing', 7),
            ('Project Management Tools', 5),
            ('Marketing Automation Tools', 5),
            ('Cloud Storage and Collaboration', 6),
            ('Social Media Presence and SEO', 8),
            ('Online Appointment Tools', 3),
            ('Supply Chain Automation', 7),
        ],
    }
    return industry_tools.get(industry_id, [])

def calculate_score(data: FormData) -> float:
    """Calculate the digital readiness score based on form data."""
    # Base scores (0-10 scaled from questionnaire options)
    weights = {
        'revenue': 0.20,
        'profit_margin': 0.18,
        'cash_flow': 0.15,
        'employee': 0.10,
        'digital_skills': 0.05,
        'data_management': 0.05,
        'market_share': 0.05,
        'likability': 0.02,
        'years': 0.04,
        'debt': 0.05
    }

    scores = {
        'revenue': normalize_score(data['revenue_trend'], 4),
        'profit_margin': normalize_score(data['profit_margins'], 5),
        'cash_flow': normalize_score(data['cash_flow'], 3),
        'employee': normalize_score(data['employees'], 5),
        'digital_skills': normalize_score(data['digital_skills'], 3),
        'data_management': normalize_score(data['data_management'], 3),
        'market_share': normalize_score(data['market_share'], 3),
        'likability': normalize_score(data['likability'], 3),
        'years': normalize_score(data['years'], 5),
        'debt': normalize_score(data['debt'], 5)
    }

    # Calculate weighted base score
    base_score = sum(score * weights[key] for key, score in scores.items())

    # Industry-specific modifiers
    bonus = 0.0
    penalty = 0.0
    
    # Industry-specific logic
    industry_map = {
        1: "Retail",
        2: "Food and Beverages",
        3: "Services",
        4: "Tourism and Leisure",
        5: "Education and Arts",
        6: "Technology",
        7: "Construction and Maintenance",
        8: "Transportation",
        9: "Health and Wellness",
        10: "Manufacturing & Craftsmanship"
    }
    
    industry = industry_map.get(int(data['industry']))
    
    if industry == "Retail":
        if data['market_share'] <= 2:
            if data['usp'] == 3:
                bonus += 1.0
            elif data['usp'] == 2:
                bonus += 0.5
        if any(tool in ['1', '2'] for tool in data['digital_strategy']):
            if data['digital_skills'] == 1:
                penalty += 1.0
    elif industry == "Food and Beverages":
        if data['customer_base'] == 'B2C' and data['digital_skills'] <= 2:
            penalty += 0.5
    elif industry == "Tourism and Leisure":
        if '5' in data['digital_strategy']:  # Digital Marketing
            bonus += 0.5
    elif industry == "Technology":
        if data['digital_skills'] < 3:
            penalty += 1.0
    elif industry == "Manufacturing & Craftsmanship":
        if data['data_management'] == 1:
            penalty += 0.5

    # Calculate final score (ensure between 0-10)
    final_score = max(0.0, min(10.0, base_score * 10 + bonus - penalty))
    return round(final_score, 2)

def generate_recommendations(score: float, data: FormData) -> List[str]:
    """Generate recommendations based on score and form data."""
    recommendations = []

    # Core recommendations based on score
    if score < 4:
        recommendations.extend([
            "Core Recommendations:",
            "- Focus on stabilizing core business operations before major digital investments",
            "- Consider basic digital tools for immediate efficiency gains"
        ])
    elif score < 7:
        recommendations.extend([
            "Core Recommendations:",
            "- Gradually implement digital solutions while building team capabilities",
            "- Invest in employee digital skills training"
        ])
    else:
        recommendations.extend([
            "Core Recommendations:",
            "- Accelerate digital transformation initiatives",
            "- Consider advanced automation and AI-powered solutions"
        ])

    # Add industry-specific tool recommendations
    industry_id = int(data['industry'])
    tools = get_industry_tools(industry_id)
    
    if tools:
        recommendations.append("\nRecommended Digital Tools:")
        for tool_name, priority in tools:
            recommendations.append(f"{tool_name}\t{priority}")

    return recommendations

def calculate_strategy(data: FormData) -> StrategyResult:
    """Calculate strategy and generate recommendations."""
    score = calculate_score(data)
    recommendations = generate_recommendations(score, data)
    
    return StrategyResult(
        score=score,
        recommendations=recommendations,
        metis_link='https://metisagile.com'
    )

# Example usage
if __name__ == "__main__":
    # Sample data for testing
    sample_data: FormData = {
        "industry": "1",  # Retail
        "years": 3,
        "employees": 2,
        "revenue_trend": 3,
        "likability": 2,
        "market_share": 1,
        "customer_base": "B2C",
        "usp": 2,
        "digital_skills": 1,
        "data_management": 1,
        "profit_margins": 3,
        "debt": 2,
        "cash_flow": 2,
        "digital_strategy": ["1", "2"],
        "email": "test@example.com",
        "phone": "+1234567890"
    }
    
    result = calculate_strategy(sample_data)
    print(f"Digital Readiness Score: {result.score}")
    print("\nRecommendations:")
    for rec in result.recommendations:
        print(rec)
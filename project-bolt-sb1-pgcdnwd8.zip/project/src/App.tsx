import React, { useState } from 'react';
import { ArrowRight, Building2, BarChart3, Send, ExternalLink, ArrowLeft, Home, HelpCircle } from 'lucide-react';
import * as Tooltip from '@radix-ui/react-tooltip';
import { questions } from './questions';
import { supabase } from './lib/supabase';
import type { FormData } from './types';

function App() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [formData, setFormData] = useState<Partial<FormData>>({
    digital_strategy: [] // Initialize digital_strategy as empty array
  });
  const [contactInfo, setContactInfo] = useState({ email: '', phone: '' });
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{
    score: number;
    recommendations: string[];
    metisLink: string;
  } | null>(null);
  const [consent, setConsent] = useState(false);
  const progress = ((currentQuestion + 1) / questions.length) * 100;

  const handleBack = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(prev => prev - 1);
    }
  };

  const goToStart = () => {
    setCurrentQuestion(0);
  };

  const handleAnswer = (value: number | number[]) => {
    const currentQ = questions[currentQuestion];
    
    if (currentQ.multiple) {
      // Ensure currentValues is initialized as an array
      const currentValues = Array.isArray(formData[currentQ.id as keyof FormData]) 
        ? (formData[currentQ.id as keyof FormData] as number[])
        : [];
      
      const newValues = currentValues.includes(value as number) 
        ? currentValues.filter(v => v !== value)
        : [...currentValues, value];
      
      setFormData(prev => ({
        ...prev,
        [currentQ.id]: newValues
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [currentQ.id]: value
      }));
      setCurrentQuestion(prev => prev + 1);
    }
  };

  const handleContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Ensure digital_strategy is an array before submission
      const submissionData = {
        ...formData,
        ...contactInfo,
        digital_strategy: formData.digital_strategy || [] // Provide fallback empty array
      };

      // Get strategy calculation from edge function
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/calculate-strategy`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(submissionData),
        }
      );

      if (!response.ok) {
        throw new Error('Failed to calculate strategy');
      }

      const result = await response.json();

      // Store response in Supabase
      const { error: dbError } = await supabase
        .from('survey_responses')
        .insert([{
          ...submissionData,
          score: result.score
        }]);

      if (dbError) {
        console.error('Database error:', dbError);
        throw new Error('Failed to save response');
      }

      setResult(result);
    } catch (error) {
      console.error('Error:', error);
      // Handle error appropriately
    } finally {
      setLoading(false);
    }
  };

  const handleNextForMultiple = () => {
    if (questions[currentQuestion].multiple) {
      setCurrentQuestion(prev => prev + 1);
    }
  };

  if (result) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
        <header className="bg-white shadow-sm">
          <div className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
            <h1 className="text-3xl font-bold text-gray-900">DigiGreece</h1>
          </div>
        </header>

        <main className="max-w-7xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
          <div className="bg-white rounded-2xl shadow-xl p-8 max-w-2xl mx-auto">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Your Digital Readiness Score</h2>
              <div className="w-32 h-32 mx-auto mb-4 relative">
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-4xl font-bold text-blue-600">{result.score}</span>
                </div>
                <svg className="w-full h-full" viewBox="0 0 36 36">
                  <path
                    d="M18 2.0845
                      a 15.9155 15.9155 0 0 1 0 31.831
                      a 15.9155 15.9155 0 0 1 0 -31.831"
                    fill="none"
                    stroke="#E2E8F0"
                    strokeWidth="3"
                  />
                  <path
                    d="M18 2.0845
                      a 15.9155 15.9155 0 0 1 0 31.831
                      a 15.9155 15.9155 0 0 1 0 -31.831"
                    fill="none"
                    stroke="#3B82F6"
                    strokeWidth="3"
                    strokeDasharray={`${result.score * 10}, 100`}
                  />
                </svg>
              </div>
            </div>

            <div className="mb-8">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Recommendations</h3>
              <div className="space-y-6">
                {result.recommendations.map((recommendation, index) => {
                  if (recommendation.startsWith('Core Recommendations:')) {
                    return (
                      <div key={index} className="bg-blue-50 rounded-lg p-4">
                        <h4 className="font-semibold text-blue-900 mb-2">{recommendation}</h4>
                      </div>
                    );
                  } else if (recommendation.startsWith('Recommended Digital Tools:')) {
                    return (
                      <div key={index} className="bg-indigo-50 rounded-lg p-4">
                        <h4 className="font-semibold text-indigo-900 mb-2">{recommendation}</h4>
                      </div>
                    );
                  } else if (recommendation.startsWith('-')) {
                    return (
                      <div key={index} className="pl-4">
                        <p className="text-gray-800">{recommendation}</p>
                      </div>
                    );
                  } else {
                    const [tool, priority] = recommendation.split('\t');
                    if (priority) {
                      return (
                        <div key={index} className="flex items-center justify-between bg-white border border-gray-200 rounded-lg p-4">
                          <span className="text-gray-800">{tool}</span>
                          <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                            Priority: {priority}
                          </span>
                        </div>
                      );
                    }
                    return (
                      <p key={index} className="text-gray-800">{recommendation}</p>
                    );
                  }
                })}
              </div>
            </div>

            <div className="text-center">
              <p className="text-gray-600 mb-4">
                Need expert guidance to implement these recommendations?
              </p>
              <a
                href="https://www.metisagile.com"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-blue-600 hover:text-blue-700 font-semibold"
              >
                Visit MetisAgile <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-bold text-gray-900">DigiGreece</h1>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-6">
            Personalized Digitalization Strategies Powered by AI
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            This platform uses AI and machine learning to analyze your company's data 
            and deliver tailored digitalization recommendations. By securely sharing 
            key information, you'll receive strategic insights customized to your 
            business needs and growth stage.
          </p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-8 mb-16">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">
                Why Digitalization Matters
              </h3>
              <p className="text-gray-600">
                In today's fast-paced, technology-driven world, digital transformation 
                is no longer optional—it's essential. Embracing digital tools and 
                processes enhances efficiency, customer experience, and decision-making. 
                It empowers businesses to adapt quickly, scale sustainably, and remain 
                competitive in ever-evolving markets. Investing in digitalization today 
                sets the foundation for long-term success tomorrow.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-blue-50 p-6 rounded-xl text-center">
                <Building2 className="w-12 h-12 text-blue-600 mx-auto mb-2" />
                <p className="font-semibold text-blue-900">Business Growth</p>
              </div>
              <div className="bg-indigo-50 p-6 rounded-xl text-center">
                <BarChart3 className="w-12 h-12 text-indigo-600 mx-auto mb-2" />
                <p className="font-semibold text-indigo-900">Data-Driven Decisions</p>
              </div>
            </div>
          </div>
        </div>

        {!result && currentQuestion < questions.length && (
          <div className="bg-white rounded-2xl shadow-xl p-8 max-w-2xl mx-auto">
            <div className="flex justify-between mb-6">
              <button
                onClick={handleBack}
                className={`flex items-center gap-2 text-gray-600 hover:text-blue-600 transition-colors ${
                  currentQuestion === 0 ? 'invisible' : ''
                }`}
              >
                <ArrowLeft className="w-4 h-4" />
                Back
              </button>
              <button
                onClick={goToStart}
                className="flex items-center gap-2 text-gray-600 hover:text-blue-600 transition-colors"
              >
                <Home className="w-4 h-4" />
                Go to Start
              </button>
            </div>

            <div className="mb-8">
              <h4 className="text-xl font-semibold text-gray-900 mb-4">
                {questions[currentQuestion].text}
              </h4>
              <div className="space-y-3">
                {questions[currentQuestion].options.map((option) => {
                  const isMultiple = questions[currentQuestion].multiple;
                  const isSelected = isMultiple 
                    ? (formData[questions[currentQuestion].id as keyof FormData] as number[] || []).includes(option.value)
                    : false;

                  return (
                    <Tooltip.Provider key={option.value}>
                      <Tooltip.Root>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleAnswer(option.value)}
                            className={`w-full text-left px-4 py-3 rounded-lg border
                                     ${isSelected 
                                       ? 'border-blue-500 bg-blue-50' 
                                       : 'border-gray-200 hover:border-blue-500 hover:bg-blue-50'} 
                                     transition-colors flex items-center justify-between group`}
                          >
                            <span>{option.label}</span>
                            <ArrowRight className="w-4 h-4 text-blue-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                          </button>
                          {'tooltip' in option && (
                            <Tooltip.Trigger asChild>
                              <button className="p-1 hover:text-blue-600 transition-colors">
                                <HelpCircle className="w-4 h-4" />
                              </button>
                            </Tooltip.Trigger>
                          )}
                        </div>
                        {'tooltip' in option && (
                          <Tooltip.Portal>
                            <Tooltip.Content
                              className="bg-gray-900 text-white px-4 py-2 rounded-lg text-sm max-w-xs"
                              sideOffset={5}
                            >
                              {option.tooltip}
                              <Tooltip.Arrow className="fill-gray-900" />
                            </Tooltip.Content>
                          </Tooltip.Portal>
                        )}
                      </Tooltip.Root>
                    </Tooltip.Provider>
                  );
                })}
              </div>
              {questions[currentQuestion].multiple && (
                <button
                  onClick={handleNextForMultiple}
                  className="mt-6 w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
                >
                  <span>Continue</span>
                  <Send className="w-4 h-4" />
                </button>
              )}
            </div>

            <div className="mt-6">
              <div className="h-2 bg-gray-200 rounded-full">
                <div
                  className="h-2 bg-blue-500 rounded-full transition-all duration-500"
                  style={{ width: `${progress}%` }}
                />
              </div>
              <p className="text-sm text-gray-600 mt-2">
                Question {currentQuestion + 1} of {questions.length}
              </p>
            </div>
          </div>
        )}

        {!result && currentQuestion >= questions.length && (
          <div className="bg-white rounded-2xl shadow-xl p-8 max-w-2xl mx-auto">
            <div className="text-center">
              <h4 className="text-xl font-semibold text-gray-900 mb-4">
                Almost there!
              </h4>
              <p className="text-gray-600 mb-8">
                Please provide your contact information below. Once submitted, you will be directed to the next page where our AI tool will generate personalized recommendations tailored to your needs.
              </p>
              <form onSubmit={handleContactSubmit} className="space-y-4">
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    id="email"
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    value={contactInfo.email}
                    onChange={(e) => setContactInfo(prev => ({ ...prev, email: e.target.value }))}
                  />
                </div>
                <div>
                  <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    id="phone"
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    value={contactInfo.phone}
                    onChange={(e) => setContactInfo(prev => ({ ...prev, phone: e.target.value }))}
                  />
                </div>
                <div className="flex items-start space-x-2 mt-4">
                  <input
                    type="checkbox"
                    id="consent"
                    required
                    checked={consent}
                    onChange={(e) => setConsent(e.target.checked)}
                    className="mt-1"
                  />
                  <label htmlFor="consent" className="text-sm text-gray-600">
                    By providing your information, you consent to its collection and use in accordance with our{' '}
                    <a href="/privacy-policy" className="text-blue-600 hover:text-blue-800 underline">
                      privacy policy
                    </a>
                    .
                  </label>
                </div>
                <button
                  type="submit"
                  disabled={loading || !consent}
                  className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed mt-6"
                >
                  <span>{loading ? 'Calculating...' : 'Get Your Digital Strategy'}</span>
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

export default App;
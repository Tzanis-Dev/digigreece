import * as Tooltip from '@radix-ui/react-tooltip';

export const questions = [
  {
    id: 'industry',
    text: 'What industry is your company in?',
    options: [
      { 
        value: 1, 
        label: 'Retail',
        tooltip: 'Grocery stores, clothing boutiques, shoe stores, furniture shops, bookstores, pharmacies, electronics shops'
      },
      { 
        value: 2, 
        label: 'Food and Beverages',
        tooltip: 'Cafes, bakeries, restaurants, taverns, fast food outlets, catering services, sweet shops, wineries, breweries'
      },
      { 
        value: 3, 
        label: 'Services',
        tooltip: 'Cleaning services, hair salons, barber shops, beauty spas, fitness centers, car repair garages, pest control'
      },
      { 
        value: 4, 
        label: 'Tourism and Leisure',
        tooltip: 'Travel agencies, tourist souvenir shops, boat rentals, diving centers, tour guide services, boutique hotels'
      },
      { 
        value: 5, 
        label: 'Education and Arts',
        tooltip: 'Language schools, tutoring centers, dance schools, music schools, art studios, IT training centers'
      },
      { 
        value: 6, 
        label: 'Technology',
        tooltip: 'IT repair services, software startups, web design agencies, SEO services'
      },
      { 
        value: 7, 
        label: 'Construction and Maintenance',
        tooltip: 'Plumbing services, electrical services, gardening and landscaping, solar panel installers, construction material suppliers'
      },
      { 
        value: 8, 
        label: 'Transportation',
        tooltip: 'Taxi companies, car rental, bicycle rentals'
      },
      { 
        value: 9, 
        label: 'Health and Wellness',
        tooltip: 'Fitness centers, veterinary clinics, massage therapy centers, yoga studios'
      },
      { 
        value: 10, 
        label: 'Manufacturing & Craftsmanship',
        tooltip: 'Olive oil producers, artisanal cheese makers, handmade soap producers'
      }
    ]
  },
  {
    id: 'employees',
    text: 'How many employees does the company have?',
    options: [
      { value: 1, label: '1' },
      { value: 2, label: '2-5' },
      { value: 3, label: '5-20' },
      { value: 4, label: '20-100' },
      { value: 5, label: 'More than 100' }
    ]
  },
  {
    id: 'years',
    text: 'How many years has your company been operating?',
    options: [
      { value: 1, label: 'Less than 1 year' },
      { value: 2, label: '1-3 years' },
      { value: 3, label: '3-5 years' },
      { value: 4, label: '5-10 years' },
      { value: 5, label: 'More than 10 years' }
    ]
  },
  {
    id: 'revenue_trend',
    text: 'How would you describe your revenue growth over the past year?',
    options: [
      { value: 1, label: 'Declining' },
      { value: 2, label: 'Stable' },
      { value: 3, label: 'Moderate growth (up to 20%)' },
      { value: 4, label: 'High growth (over 20%)' }
    ]
  },
  {
    id: 'likability',
    text: 'How would you rate your customer satisfaction levels?',
    options: [
      { value: 1, label: 'Needs improvement' },
      { value: 2, label: 'Satisfactory' },
      { value: 3, label: 'Excellent' }
    ]
  },
  {
    id: 'market_share',
    text: 'How would you describe your market position?',
    options: [
      { value: 1, label: 'Small player' },
      { value: 2, label: 'Established competitor' },
      { value: 3, label: 'Market leader' }
    ]
  },
  {
    id: 'customer_base',
    text: 'Who are your primary customers?',
    options: [
      { value: 1, label: 'B2C (Direct to consumers)' },
      { value: 2, label: 'B2B (Business to business)' },
      { value: 3, label: 'Both B2B and B2C' }
    ]
  },
  {
    id: 'usp',
    text: 'What is your main competitive advantage?',
    options: [
      { value: 1, label: 'Price' },
      { value: 2, label: 'Quality/Service' },
      { value: 3, label: 'Unique offering' }
    ]
  },
  {
    id: 'digital_skills',
    text: 'How would you rate your team\'s digital skills?',
    options: [
      { value: 1, label: 'Basic' },
      { value: 2, label: 'Intermediate' },
      { value: 3, label: 'Advanced' }
    ]
  },
  {
    id: 'data_management',
    text: 'How do you currently manage business data?',
    options: [
      { value: 1, label: 'Manual/Paper-based' },
      { value: 2, label: 'Basic digital tools' },
      { value: 3, label: 'Advanced digital systems' }
    ]
  },
  {
    id: 'profit_margins',
    text: 'What are your current profit margins?',
    options: [
      { value: 1, label: 'Below 0% (Loss)' },
      { value: 2, label: '0-5%' },
      { value: 3, label: '5-10%' },
      { value: 4, label: '10-20%' },
      { value: 5, label: 'Above 20%' }
    ]
  },
  {
    id: 'debt',
    text: 'How would you describe your company\'s debt level?',
    options: [
      { value: 1, label: 'No debt' },
      { value: 2, label: 'Low debt' },
      { value: 3, label: 'Moderate debt' },
      { value: 4, label: 'High debt' },
      { value: 5, label: 'Very high debt' }
    ]
  },
  {
    id: 'cash_flow',
    text: 'How stable is your cash flow?',
    options: [
      { value: 1, label: 'Unstable' },
      { value: 2, label: 'Moderately stable' },
      { value: 3, label: 'Very stable' }
    ]
  },
  {
    id: 'digital_strategy',
    text: 'Which digital tools are you interested in implementing?',
    options: [
      { value: 1, label: 'E-commerce platform' },
      { value: 2, label: 'Customer Relationship Management (CRM)' },
      { value: 3, label: 'Project Management tools' },
      { value: 4, label: 'HR Management System' },
      { value: 5, label: 'Digital Marketing tools' }
    ],
    multiple: true
  }
];
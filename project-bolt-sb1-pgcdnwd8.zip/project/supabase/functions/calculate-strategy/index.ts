import { createClient } from 'npm:@supabase/supabase-js@2.39.7';

interface FormData {
  industry: string;
  years: number;
  employees: number;
  revenue_trend: number;
  likability: number;
  market_share: number;
  customer_base: string;
  usp: number;
  digital_skills: number;
  data_management: number;
  profit_margins: number;
  debt: number;
  cash_flow: number;
  digital_strategy: string[];
  email?: string;
  phone?: string;
  supply_chain?: number;
  inventory_management?: number;
}

interface ToolRecommendation {
  tool_name: string;
  priority: number;
}

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

async function getToolRecommendations(industryId: number): Promise<ToolRecommendation[]> {
  const supabaseUrl = Deno.env.get('SUPABASE_URL') as string;
  const supabaseKey = Deno.env.get('SUPABASE_ANON_KEY') as string;
  const supabase = createClient(supabaseUrl, supabaseKey);

  const { data, error } = await supabase
    .from('digital_tools_recommendations')
    .select('tool_name, priority')
    .eq('industry_id', industryId)
    .order('priority', { ascending: false });

  if (error) {
    console.error('Error fetching recommendations:', error);
    return [];
  }

  return data || [];
}

function normalizeScore(value: number, scaleMax: number): number {
  return (value - 1) / (scaleMax - 1) * 10;
}

function calculateScore(data: FormData): number {
  const baseWeights = {
    revenue_trend: 0.20,
    profit_margins: 0.15,
    employees: 0.15,
    digital_maturity: 0.12,
    cash_flow: 0.12,
    market_position: 0.08,
    debt: 0.05,
    data_management: 0.05,
    years: 0.04,
    likability: 0.04
  };

  let scores = {
    revenue_trend: normalizeScore(data.revenue_trend, 4),
    profit_margins: normalizeScore(data.profit_margins, 5),
    employees: normalizeScore(data.employees, 5),
    digital_maturity: (normalizeScore(data.digital_skills, 3) + normalizeScore(data.data_management, 3)) / 2,
    cash_flow: normalizeScore(data.cash_flow, 3),
    market_position: (normalizeScore(data.market_share, 3) + normalizeScore(data.usp, 3) + normalizeScore(data.likability, 3)) / 3,
    debt: normalizeScore(data.debt, 5),
    data_management: normalizeScore(data.data_management, 3),
    years: normalizeScore(data.years, 5),
    likability: normalizeScore(data.likability, 3)
  };

  let baseScore = 0;
  for (const [key, weight] of Object.entries(baseWeights)) {
    baseScore += scores[key as keyof typeof scores] * weight;
  }

  let finalScore = baseScore;
  
  if (data.industry === '1') {
    finalScore = baseScore * 0.8;
    
    if (data.supply_chain !== undefined) {
      finalScore += normalizeScore(data.supply_chain, 5) * 0.10;
    }
    if (data.inventory_management !== undefined) {
      finalScore += normalizeScore(data.inventory_management, 5) * 0.10;
    }
  }

  const employeeScore = scores.employees;
  if (data.digital_maturity > 7 && employeeScore < 5) {
    finalScore *= 0.95;
  } else if (data.digital_maturity < 3 && employeeScore > 7) {
    finalScore *= 0.90;
  }

  return Math.max(0, Math.min(10, finalScore));
}

async function generateRecommendations(score: number, data: FormData): Promise<string[]> {
  const recommendations: string[] = [];

  // Core recommendations based on score
  if (score < 4) {
    recommendations.push("Core Recommendations:");
    recommendations.push("- Focus on stabilizing core business operations before major digital investments");
    recommendations.push("- Consider basic digital tools for immediate efficiency gains");
  } else if (score < 7) {
    recommendations.push("Core Recommendations:");
    recommendations.push("- Gradually implement digital solutions while building team capabilities");
    recommendations.push("- Invest in employee digital skills training");
  } else {
    recommendations.push("Core Recommendations:");
    recommendations.push("- Accelerate digital transformation initiatives");
    recommendations.push("- Consider advanced automation and AI-powered solutions");
  }

  recommendations.push("\nRecommended Digital Tools:");

  // Get and add industry-specific tool recommendations
  const industryId = parseInt(data.industry);
  const toolRecommendations = await getToolRecommendations(industryId);

  toolRecommendations
    .sort((a, b) => b.priority - a.priority)
    .forEach(tool => {
      recommendations.push(`${tool.tool_name}\t${tool.priority}`);
    });

  return recommendations;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const data: FormData = await req.json();
    const score = calculateScore(data);
    const recommendations = await generateRecommendations(score, data);

    const response = {
      score,
      recommendations,
      metisLink: 'https://metisagile.com',
    };

    return new Response(
      JSON.stringify(response),
      { 
        headers: { 
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      }
    );
  } catch (error) {
    console.error('Error:', error);
    return new Response(
      JSON.stringify({ error: 'Failed to process request' }),
      { 
        status: 400,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      }
    );
  }
});